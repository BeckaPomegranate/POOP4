/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poop4;

/**
 *
 * @author estudiante
 */
public class Poop4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Punto punto1 = new Punto();
        punto1.imprimirPunto();
        punto1.x=4;
        punto1.y=7;
        punto1.imprimirPunto();
        
        Punto punto2 = new Punto(10,88);
        punto2.imprimirPunto();
        
        System.out.println("Punto 2 x = "+ punto2.x);
        
        Carro carro1 = new Carro();
        carro1.imprimirCarro();
        carro1.anio= 2020;
        carro1.numPuertas = 4;
        carro1.marca= "Honda";
        carro1.color= "blanco";
        carro1.imprimirCarro();
        
        Carro carro2 = new Carro (2022, 4, "Chevrolet", "Azul");
        carro2.imprimirCarro();
        
        Profesor profesor1 = new Profesor();
        profesor1.imprimirProfesor();
        profesor1.materiaQueImparte= "Calculo";
        profesor1.horarioDeClase= 1300;
        profesor1.divisionALaQuePertenece= "Ciencias basicas";
        profesor1.universidadEnLaQueTrabaja= "UNAM";
        profesor1.imprimirProfesor();
        
        Profesor profesor2 = new Profesor ("Algebra", 1200, "Ciencias Basicas", "UAM");
        profesor2.imprimirProfesor();
        
        
    }
    
}
