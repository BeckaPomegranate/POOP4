/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop4;

/**
 *
 * @author estudiante
 */
public class Carro {
    int anio;
    int numPuertas;
    String marca;
    String color;
    
    public Carro(){
    
    }
    
    public Carro(int anio, int numPuertas, String marca, String color){
        this.anio=anio;
        this.numPuertas=numPuertas;
        this.marca=marca;
        this.color=color;
    
    }
    
    public void avanzar(){
        System.out.println("Carro avanza");
    }
    public void frenar(){
        System.out.println("Carro frena");
    }
    public void sonar(){
        System.out.println("Pip Pip");
    }
    public void retroceder(){
        System.out.println("Carro retrocede");
        
    }
    
    public void imprimirCarro(){
        System.out.println("Año: " + anio);
        System.out.println("Numero de puertas: " + numPuertas);
        System.out.println("Marca: " + marca);
        System.out.println("Color: " + color);
    }
    
    
}
