/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop4;

/**
 *
 * @author estudiante
 */
public class Profesor {
    String materiaQueImparte;
    double horarioDeClase;
    String divisionALaQuePertenece;
    String universidadEnLaQueTrabaja;
    
    public Profesor(){
        
    }
    
    public Profesor(String materiaQueImparte, double horarioDeClase, String divisionALaQuePertenece, String universidadEnLaQueTrabaja){
        this.materiaQueImparte = materiaQueImparte;
        this.horarioDeClase = horarioDeClase;
        this.divisionALaQuePertenece = divisionALaQuePertenece;
        this.universidadEnLaQueTrabaja = universidadEnLaQueTrabaja;
             
    }
    
    public void pasarLista(){
        System.out.println("Pasando lista...");
        
    }
    public void calificarTareas(){
        System.out.println("Calificando tareas...");
        
    }
    public void hacerExamenes(){
        System.out.println("Haciendo examenes faciles...");
        
    }
    public void imprimirProfesor(){
        System.out.println("Materia que imparte: " + materiaQueImparte);
        System.out.println("Horario de clase: " + horarioDeClase);
        System.out.println("Divion a la que pertenece: " + divisionALaQuePertenece);
        System.out.println("Universidad en la que trabaja: " + universidadEnLaQueTrabaja);
    }
            
    
    
}
