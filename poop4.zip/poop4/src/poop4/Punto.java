/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop4;

/**
 *
 * @author estudiante
 */
public class Punto {
    int x;
    int y;
    
    //Mètodos
    //Metodo constructor
    public Punto(){
        //x=0;
        //y=0;e como inicializarlo, no es necesario ponerlos, el constructor vacio ya lo hace
        
    }
    public Punto(int x, int y){
        this.x= x;
        this.y= y;
    }
    
    
    //Metodo de acciòn
    public void imprimirPunto(){
        System.out.println("("+x+","+y+")");
    }
}
